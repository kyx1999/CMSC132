package tests;

import static org.junit.Assert.*;

import org.junit.Test;

public class StudentTests {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
