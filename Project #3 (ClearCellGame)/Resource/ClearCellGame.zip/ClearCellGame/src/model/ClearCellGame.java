package model;

import java.util.Random;

/* This class must extend Game */
public class ClearCellGame  {

}