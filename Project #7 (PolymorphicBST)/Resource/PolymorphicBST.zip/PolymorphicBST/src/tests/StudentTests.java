package tests;

import junit.framework.TestCase;

public class StudentTests extends TestCase {
	
	
}