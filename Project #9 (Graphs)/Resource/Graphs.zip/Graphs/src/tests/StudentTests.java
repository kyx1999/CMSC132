package tests;
import junit.framework.TestCase;

/**
 * Please put your own test cases into this file.
*/

public class StudentTests extends TestCase {
	
}